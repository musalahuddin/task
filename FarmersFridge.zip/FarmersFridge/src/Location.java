import java.util.*;


public class Location {

	public String key;
	
	public Map<String, Par> pars = new HashMap<String,Par>();
	
}