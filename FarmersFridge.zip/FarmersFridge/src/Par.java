
public class Par {
	
	public String key;
	
	public double value;
	
}
