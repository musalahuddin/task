import java.util.*;


public class Day {

	public String key;
	
	public Map<String, Location> locations = new HashMap<String,Location>();
	
}