import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Main {
	
	/**
	 * input file
	 */
	private static final String FILE_NAME = "test data.xlsx";
    
	/**
	 * reference to the complete data set
	 */
	public static Map<String, Day> days = new HashMap<String,Day>();
	
	public static void main(String[] args) {
		
		loadAndMapData();
		
		//printDataMap();
		
		createDirectories();
		
		generateXMLs();
	}
	
	/**
	 * loads and maps data into Map<String, Day> days
	 */
	public static void loadAndMapData(){
		
		System.out.println("loading and mapping data..");
		
		 try {

	            FileInputStream excelFile = new FileInputStream(new File(FILE_NAME));
	            Workbook workbook = new XSSFWorkbook(excelFile);
	            Sheet datatypeSheet = workbook.getSheetAt(0);
	            Iterator<Row> rowIterator = datatypeSheet.iterator();
	            
	            // fields representing columns in the spread sheet
	            String location="", item="", day="";
	            int par=0;
	            
	            // fields representing instances
	            Day d; 
	            Location l; 
	            Par p; 
	            
	            while (rowIterator.hasNext()) {
	            	
	                Row currentRow = rowIterator.next();
	                int rowNum = currentRow.getRowNum();
	                
	                //ignoring the first row of the spread sheet
	                if(rowNum == 0) continue;
	                
	                Iterator<Cell> cellIterator = currentRow.iterator();
	                

	                while (cellIterator.hasNext()) {
	                	
	                	
	                	Cell currentCell = cellIterator.next();
	                    
	                	int cellNum = currentCell.getColumnIndex();
	                	
	                	switch(cellNum){
		                	case 0: //Location field
		                		location = currentCell.getStringCellValue();
		                		break;
		                	case 1: //Item field
		                		item = currentCell.getStringCellValue();
		                		break;
		                	case 2: //Day field
		                		day = currentCell.getStringCellValue().substring(0, 3);
		                		break;
		                	case 3: //Par field
		                		par = (int) currentCell.getNumericCellValue();
		                		break;
	                	}   
	                }
	                
	                if(day == "") continue;
	        	
	        		//Here is where we map the data
	        		
	                //Day
	                if (days.get(day) != null){
	        			d = days.get(day);
	        		}
	        		else{
	        			d = new Day();
	        			d.key = day;
	        			
	        			days.put(day, d);
	        		}
	        		
	        		
	        		//Location
	        		if(d.locations.get(location) != null){
	        			l = d.locations.get(location);
	        		}
	        		else{
	        			l = new Location();
	        			l.key = location;
	        			
	        			d.locations.put(location, l);
	        		}
	        		
	        		//Par
	        		if(l.pars.get(item) != null){
	        			p = l.pars.get(item);
	        		}
	        		else{
	        			p = new Par();
	        			p.key = item;
	        			p.value = par;
	        			
	        			l.pars.put(item, p);
	        		}
	            }
		 }
		 catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
	}
	
	/**
	 * create Directories (i.e. Mon - Fri) 
	 */
	public static void createDirectories(){
		
		System.out.println("creating directories..");
		
		for (Day day : days.values()) {
            File dir = new File(day.key);
            
            // attempt to create the directory here
            boolean successful = dir.mkdir();
            if (successful)
            {
              // creating the directory succeeded
              System.out.println("directory was created successfully");
            }
            else
            {
              // creating the directory failed
              System.out.println("failed trying to create the directory");
            }
        }
	}
	
	/**
	 * generates xmls
	 */
	public static void generateXMLs(){
		System.out.println("generating xmls..");
		
		try {
    		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
    		
    		
    		for (Day day : days.values()) {
            	
            	for(Location location : day.locations.values()){
            		
            		// root element
            		Document doc = docBuilder.newDocument();
            		Element rootElement = doc.createElement("parMap");
            		doc.appendChild(rootElement);
            		
            		// location element
            		Element loc = doc.createElement("name");
            		loc.appendChild(doc.createTextNode(location.key));
            		rootElement.appendChild(loc);
            		
            		// pars element
            		Element pars = doc.createElement("pars");
            		rootElement.appendChild(pars);
            		
        
            		for(Par par : location.pars.values()){
            			
            			// entry element
            			Element entry = doc.createElement("entry");
                		pars.appendChild(entry);
                		
                		// key element
                		Element key = doc.createElement("key");
                		key.appendChild(doc.createTextNode(par.key));
                		entry.appendChild(key);
                		
                		// value element
                		Element value = doc.createElement("value");
                		value.appendChild(doc.createTextNode(String.valueOf(par.value)));
                		entry.appendChild(value);
            	   }
            		
            		// write the content into xml file
            		TransformerFactory transformerFactory = TransformerFactory.newInstance();
            		Transformer transformer = transformerFactory.newTransformer();
            		DOMSource source = new DOMSource(doc);
            		StreamResult result = new StreamResult(new File(day.key+"/"+location.key+".xml"));

            		// Output to console for testing
            		// StreamResult result = new StreamResult(System.out);

            		transformer.transform(source, result);
               }
            }
    		
    		System.out.println("finished.");
    		

    	  } catch (ParserConfigurationException pce) {
    		pce.printStackTrace();
    	  }catch (TransformerException tfe) {
    		tfe.printStackTrace();
    	  }
	}
	
	/**
	 * prints data for debugging
	 */
	public static void printDataMap(){
		 for (Day day : days.values()) {
         	System.out.println("day = " + day.key);
         	for(Location location : day.locations.values()){
         		System.out.println("location = " + location.key);
         	   for(Par par : location.pars.values()){
         		   System.out.println("par key = " + par.key);
         		   System.out.println("par value = " + String.valueOf(par.value));
         	   }
            }
         }
	}
    
}
